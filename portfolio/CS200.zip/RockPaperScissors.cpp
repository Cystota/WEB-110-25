// Keagna Fraser 2/24/36
#include <iostream>
using namespace std;

int main() {
	const short rock = 0, paper = 1, scissors = 2;
	short rounds;
	short p1Score = 0, p2Score = 0;
	string player1, player2;
	char response;
	
	do {
		cout << "Player 1 name is: ";
		cin >> player1;
		cout << "Player 2 name is: ";
		cin >> player2;

		cout << "Enter number of rounds to play: ";
		cin >> rounds;

		//Don't pass unless round count is positve
		while (rounds <= 0) {
			cout << "Number of rounds must be greater than zero" << endl;
			cout << "Enter number of rounds to play: ";
			cin >> rounds;
		}

		//Process each round of the game
		for (; rounds != 0; --rounds) {
			short player1Move, player2Move;
			string player1Text, player2Text;
			player1Move = rand() % 3;
			player2Move = rand() % 3;

			// Assign a string the name of the move that has been made
			switch (player1Move) {
			case 0: player1Text = "rock";
				break;
			case 1: player1Text = "paper";
				break;
			case 2: player1Text = "scissors";
				break;
			}

			switch (player2Move) {
			case 0: player2Text = "rock";
				break;
			case 1: player2Text = "paper";
				break;
			case 2: player2Text = "scissors";
				break;
			}

			if (player1Move == player2Move) {
				cout << "Tie" << endl;
			}
			// Logic: (0 beats 2), (1 beats 0), (2 beats 1)
			// Assume player 2 wins if all conditions of player 1 winning don't exist
			else if ((player1Move == 0 && player2Move == 2) ||
				(player1Move == 1 && player2Move == 0) ||
				(player1Move == 2 && player2Move == 1)) {
				cout << player1 << " plays " << player1Text << " " << player2 << " Plays " << player2Text
					<< " --> " << player1 << " wins!" << endl;
				++p1Score;
			}
			else {
				cout << player1 << " plays " << player1Text << " " << player2 << " Plays " << player2Text
					<< " --> " << player2 << " wins!" << endl;
				++p2Score;
			}

		}

		//output the scores for each contenstant and print out who won
		cout << "Final Score: " << player1 << " " << p1Score << " vs. " << player2 << " " << p2Score << endl;
		if (p1Score > p2Score) cout << player1 << " WON!";
		else if (p1Score < p2Score) cout << player2 << " WON!" << endl;
		else cout << "It's a tie" << endl;

		cout << "Do you want to play again? ";
		cin >> response;

	} while (response == 'Y' || response == 'y');

	return 0;
}