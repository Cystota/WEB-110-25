#include <iostream>
using namespace std;

int main() {
	int cartonContentCount, amountItemsOrdered;
	int cartonAmount, nonCartonProduct;
	
	cout << "How many items are in a carton? ";
	cin >> cartonContentCount;
	cout << "Total number of items ordered: ";
	cin >> amountItemsOrdered;

	cartonAmount = amountItemsOrdered / cartonContentCount;
	nonCartonProduct = amountItemsOrdered % cartonContentCount;

	cout << cartonAmount << " Cartons and " << nonCartonProduct << " Singles";

	return 0;
}