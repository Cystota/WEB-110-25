//Keagan Fraser 2/25/26
#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    short max = 25;
    short termCount;
    char response;

    do {
        // Reset values before a new sequence has begun
        unsigned short num1 = 0, num2 = 1;
        short lineLength = 0; 

        //Trap the user until the amount of terms make the math possible in usigned short
        do {
            cout << "How many terms of the Fibonnaci Series do you want? ";
            cin >> termCount;
            if (termCount >= max) cout << "Enter a number less than " << max << "." << endl;
        } while (termCount >= max);
        
        //Print out the amount of terms as the user requested
        while (termCount > 0) {

            //Print the current number in the sequence
            if (lineLength == 4) {
                cout << setw(7) << num1 << endl;
                lineLength = 0;
            }
            else {
                cout << setw(7) << num1;
                lineLength++;
            }

            //Calculate the next number and shift the values
            unsigned short transfer = num1 + num2;
            num1 = num2;
            num2 = transfer;

            --termCount;
        }

        cout << endl << "Do you want to run another series? ";
        cin >> response;

    } while (toupper(response) == 'Y');

    return 0;
}