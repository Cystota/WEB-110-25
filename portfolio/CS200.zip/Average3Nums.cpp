#include <iostream>
using namespace std;

int main() {
	short num1, num2, num3;
	float result;

	cout << "Enter the first integer: ";
	cin >> num1;
	cout << "Enter the second integer: ";
	cin >> num2;
	cout << "Enter the third integer: ";
	cin >> num3;

	result = (float)(num1 + num2 + num3) / 3;

	cout << "The average is: " << result;
	return 0;
}