//Keagan Fraser 2/5/26
#include <iostream>
using namespace std;

int main() {
    const float CO2_PER_TREE_YEAR = 48.0;
    const float MW_CO2 = 44.0;
    const float MW_O2 = 32.0;
    const float DAYS_IN_YEAR = 365.0;
    const float CONVERSION_FACTOR = MW_O2 / MW_CO2;

    int numTrees;

    cout << "Enter the number of mature trees: ";
    cin >> numTrees;    

    float dailyO2 = ((numTrees * CO2_PER_TREE_YEAR) * CONVERSION_FACTOR) / DAYS_IN_YEAR

    cout << "Daily Oxygen Produced:  " << dailyO2 << " lbs" << endl;

    return 0;
}