//Keagan Fraser 2/10/26
#include <iostream>
using namespace std;

int main() {
	const float LOCKOUT_LEVEL = 0.08;
	float userBALevel;

	//Get blood alchohol level from the user
	cout << "This is a new car feature, not court-ordered. \nBlow in the tube!" << endl;
	cout << "What is the blood-alcohol content reading? ";
	cin >> userBALevel;

	if (userBALevel >= LOCKOUT_LEVEL)
		cout << "The ignition is locked, you cannot drive at this time.";
	else
		cout << "You are good to go.";

	return 0;
}