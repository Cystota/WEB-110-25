#include <iostream>
using namespace std;

int main() {
	short sNum;
	long lNum;
	float fNum;
	
	//Retrieve Float
	cout << "Enter a float: ";
	cin >> fNum;
	//Retrieve short
	cout << "Enter a number less than 6,000: ";
	cin >> sNum;
	//Retrieve long
	cout << "Enter a number greater than 70,000: ";
	cin >> lNum;

	//Output User Numbers
	cout << "Float " << fNum << " Short " << sNum << " Long " << lNum;
	
	cout << endl << "Float as a short: " << (short)fNum << endl;
	cout << "Short as a float: " << (float)sNum << endl;	
	cout << "Long as a short: " << (short)lNum;
}