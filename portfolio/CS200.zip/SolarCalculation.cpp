// Keagan Fraser 2/9/26
#include <iostream>
#include <iomanip>
using namespace std;

int main() {
	const short KANSAS_RATE = 883, NEBRASKA_RATE = 1013, MISSOURI_RATE = 1028, COLORADO_RATE = 711;
	const float KANSAS_SUN = 4.7, NEBRASKA_SUN = 4.5, MISSOURI_SUN = 4.5, COLORADO_SUN = 5.0;
	const float EFFICIENCY_FACTOR = 1.15;
	char userState;

	//Get the state the user wants calculated
	cout << "K: Kansas\nM: Missouri\nN: Nebraska\nC: Colorado" << endl;
	cin >> userState;

	switch (toupper(userState)) {
	case 'K':
		cout << fixed << setprecision(1) << (((float)KANSAS_RATE / 30) / KANSAS_SUN) * EFFICIENCY_FACTOR << "kW DC solar system size is needed.";
		break;
	case 'M':
		cout << fixed << setprecision(1) << (((float)MISSOURI_RATE / 30) / MISSOURI_SUN) * EFFICIENCY_FACTOR  << "kW DC solar system size is needed.";
		break;
	case 'N':
		cout << fixed << setprecision(1) << (((float)NEBRASKA_RATE / 30) / NEBRASKA_SUN) * EFFICIENCY_FACTOR  << "kW DC solar system size is needed.";
		break;
	case 'C':
		cout << fixed << setprecision(1) << (((float)COLORADO_RATE / 30) / COLORADO_SUN) * EFFICIENCY_FACTOR  << "kW DC solar system size is needed.";
		break;
	}

	return 0;
}