// Keagan Fraser 2/11/26
#include <iostream>
using namespace std;

int main() {
	short highwayNum;

	cout << "What is the interstate highway number? ";
	cin >> highwayNum;

	if (highwayNum > 100) {
		//obtain the first number that determines what type of aux highway
		short auxHightwayBase = (highwayNum / 100) % 10;

		//Output what kind of aux highway and then subtract 100 so that the remaining value is fed into the next if correctly
		if (auxHightwayBase % 2 == 0) {
			cout << highwayNum << " is an auxillary highway that goes around a city." << endl <<
				"The primary highway is " << highwayNum - 100 << endl;
			highwayNum -= 100;
		}
		else {
			cout << highwayNum << " is an auxillary highway that goes around a city." << endl <<
				"The primary highway is " << highwayNum - 100 << endl;
			highwayNum -= 100;
		}
		}

	//Output the direction of the highway
	if (highwayNum % 2 == 0) cout << "Interstate highway " << highwayNum << " travels east/west" << endl;
	else cout << "Interstate highway " << highwayNum << " travels north/south" << endl;
	return 0;
}